package com.example.groceryreceipt

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.content.ContentValues
import android.os.Bundle
import android.webkit.*
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import kotlinx.coroutines.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import android.util.Base64

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private val http = OkHttpClient()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var cameraUri: Uri? = null
    private val FILE_CHOOSER = 9001

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(v: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val camera = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, "receipt_${System.currentTimeMillis()}.jpg")
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Receipts")
                }
                cameraUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (cameraUri != null) {
                    camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri)
                    camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val gallery = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) }
                val chooser = Intent.createChooser(gallery, "Выбрать чек или сфотографировать")
                if (cameraUri != null) chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(camera))
                startActivityForResult(chooser, FILE_CHOOSER)
                return true
            }
        }
        web.addJavascriptInterface(AndroidBridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class AndroidBridge {
        @JavascriptInterface fun openSettings() = runOnUiThread { showSettings() }
        @JavascriptInterface fun scanReceipt(dataUrl: String) {
            val key = prefs.getString("api_key", "") ?: ""
            if (key.isBlank()) {
                runOnUiThread {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Нужен OpenAI API key")
                        .setMessage("Добавь свой API-ключ в настройках AI. Он нужен для распознавания фотографии чека.")
                        .setPositiveButton("Настроить") { _, _ -> showSettings() }
                        .setNegativeButton("Отмена", null).show()
                }
                return
            }
            scope.launch { analyzeReceipt(key, dataUrl) }
        }
    }

    private fun showSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32) }
        val info = TextView(this).apply { text = "Для распознавания чеков нужен личный OpenAI API key. Он оплачивается отдельно по использованию API."; setPadding(0,0,0,18) }
        val input = EditText(this).apply { hint = "sk-..."; setSingleLine(true); setText(prefs.getString("api_key", "")) }
        box.addView(info); box.addView(input)
        AlertDialog.Builder(this).setTitle("AI для чеков").setView(box)
            .setPositiveButton("Сохранить") { _, _ -> prefs.edit().putString("api_key", input.text.toString().trim()).apply() }
            .setNegativeButton("Отмена", null).show()
    }

    private suspend fun analyzeReceipt(key: String, dataUrl: String) = withContext(Dispatchers.IO) {
        try {
            val categories = "ХЛЕБ И ВЫПЕЧКА, МОЛОЧНЫЕ ПРОДУКТЫ, МЯСО, РЫБА, ОВОЩИ, ФРУКТЫ, БАКАЛЕЯ, КОНСЕРВЫ И СОУСЫ, ЗАМОРОЗКА, СЛАДОСТИ, НАПИТКИ, ДЛЯ ДОМА"
            val prompt = """
Ты распознаёшь польский/европейский кассовый чек. Верни ТОЛЬКО JSON по заданной схеме.
Для каждой позиции определи обычный русский тип товара без бренда: например бренд хлеба -> Хлеб, бренд молока -> Молоко.
Сопоставь каждую позицию с одной из категорий: $categories.
price — итоговая цена строки в PLN как число. Не включай номер строки, количество или код товара в цену.
Если в чеке есть НДС/VAT (PTU/VAT) и можно определить общую сумму налога, положи её в tax_total. Если налог не указан явно, используй 0.
Не выдумывай позиции. Если строка не является товаром (скидка, способ оплаты, номер кассы), пропусти её.
""".trimIndent()
            val content = JSONArray()
                .put(JSONObject().put("type", "input_text").put("text", prompt))
                .put(JSONObject().put("type", "input_image").put("image_url", dataUrl).put("detail", "high"))
            val input = JSONArray().put(JSONObject().put("role", "user").put("content", content))

            val itemSchema = JSONObject().apply {
                put("type", "object")
                put("properties", JSONObject().apply {
                    put("category", JSONObject().put("type", "string"))
                    put("item", JSONObject().put("type", "string"))
                    put("price", JSONObject().put("type", "number"))
                })
                put("required", JSONArray().put("category").put("item").put("price"))
                put("additionalProperties", false)
            }
            val schema = JSONObject().apply {
                put("type", "object")
                put("properties", JSONObject().apply {
                    put("items", JSONObject().apply { put("type", "array"); put("items", itemSchema) })
                    put("tax_total", JSONObject().put("type", "number"))
                })
                put("required", JSONArray().put("items").put("tax_total"))
                put("additionalProperties", false)
            }
            val body = JSONObject().apply {
                put("model", "gpt-5.6-luna")
                put("input", input)
                put("text", JSONObject().apply {
                    put("format", JSONObject().apply {
                        put("type", "json_schema")
                        put("name", "receipt_items")
                        put("strict", true)
                        put("schema", schema)
                    })
                })
            }
            val req = Request.Builder().url("https://api.openai.com/v1/responses")
                .addHeader("Authorization", "Bearer $key")
                .addHeader("Content-Type", "application/json")
                .post(body.toString().toRequestBody("application/json".toMediaType())).build()
            val resp = http.newCall(req).execute()
            val text = resp.body?.string() ?: ""
            if (!resp.isSuccessful) throw Exception("HTTP ${resp.code}: $text")
            val root = JSONObject(text)
            val output = root.optJSONArray("output") ?: throw Exception("No output")
            var json = ""
            for (i in 0 until output.length()) {
                val item = output.getJSONObject(i)
                val contentOut = item.optJSONArray("content") ?: continue
                for (j in 0 until contentOut.length()) {
                    val part = contentOut.getJSONObject(j)
                    if (part.optString("type") == "output_text") { json = part.optString("text"); break }
                }
                if (json.isNotBlank()) break
            }
            if (json.isBlank()) throw Exception("No structured output")
            withContext(Dispatchers.Main) { web.evaluateJavascript("window.applyReceipt(${JSONObject.quote(json)});", null) }
        } catch (e: Exception) {
            withContext(Dispatchers.Main) {
                val msg = JSONObject.quote("⚠️ Ошибка распознавания: ${e.message ?: "неизвестная ошибка"}")
                web.evaluateJavascript("document.getElementById('cameraStatus').textContent=$msg;document.getElementById('cameraStatus').classList.add('show');", null)
            }
        }
    }

    @Deprecated("Deprecated in Android API; kept for WebView file chooser compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != FILE_CHOOSER) return
        val cb = fileCallback ?: return
        fileCallback = null
        if (resultCode == RESULT_OK) {
            val uri = data?.data ?: cameraUri
            if (uri != null) cb.onReceiveValue(arrayOf(uri)) else cb.onReceiveValue(null)
        } else {
            cameraUri?.let { runCatching { contentResolver.delete(it, null, null) } }
            cb.onReceiveValue(null)
        }
        cameraUri = null
    }

    override fun onDestroy() { scope.cancel(); web.destroy(); super.onDestroy() }
}
