plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.example.groceryreceipt"; compileSdk = 36
    defaultConfig { applicationId = "com.example.groceryreceipt"; minSdk = 26; targetSdk = 36; versionCode = 1; versionName = "1.0" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.webkit:webkit:1.14.0")
    implementation("com.squareup.okhttp3:okhttp:5.1.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
}
